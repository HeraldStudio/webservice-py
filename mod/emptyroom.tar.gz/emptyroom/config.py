#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date    : 2015-03-13 13:54:41
# @Author  : yml_bright@163.com

#######################
# main.py 
#######################
# 学期信息
course_term = '16-17-3'
course_term_id = '16-17-3'
exam_term = '16-17-3'
start_year = 2017
start_month = 2
start_day = 21

#######################
# handler.py 
#######################
